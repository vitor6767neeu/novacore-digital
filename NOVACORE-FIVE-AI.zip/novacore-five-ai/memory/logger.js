import pino from "pino";
import { config } from "./config.js";

export function logger(service) {
  return pino({
    name: service,
    level: config.logLevel,
    redact: {
      paths: [
        "*.apiKey",
        "*.token",
        "*.password",
        "*.authorization",
        "OPENAI_API_KEY",
        "TELEGRAM_BOT_TOKEN",
        "FIREBASE_SERVICE_ACCOUNT_JSON",
      ],
      remove: true,
    },
  });
}
