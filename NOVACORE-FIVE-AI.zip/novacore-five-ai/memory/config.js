/**
 * Configuração central das cinco IAs.
 * Tudo sensível vem de variáveis de ambiente / Secrets.
 */
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");

function env(name, fallback = "") {
  return process.env[name] ?? fallback;
}

function envInt(name, fallback) {
  const v = process.env[name];
  if (v === undefined || v === "") return fallback;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export const config = {
  env: env("NODE_ENV", "production"),
  logLevel: env("LOG_LEVEL", "info"),
  root,

  openai: {
    apiKey: env("OPENAI_API_KEY"),
    model: env("OPENAI_MODEL", "gpt-4o-mini"),
    baseUrl: env("OPENAI_BASE_URL") || undefined,
  },

  firebase: {
    projectId: env("FIREBASE_PROJECT_ID", "auto-bot-701e3"),
    databaseURL: env(
      "FIREBASE_DATABASE_URL",
      "https://auto-bot-701e3-default-rtdb.firebaseio.com"
    ),
    storageBucket: env(
      "FIREBASE_STORAGE_BUCKET",
      "auto-bot-701e3.firebasestorage.app"
    ),
    serviceAccountJson: env("FIREBASE_SERVICE_ACCOUNT_JSON"),
    serviceAccountPath: env("FIREBASE_SERVICE_ACCOUNT_PATH"),
    apiKey: env("FIREBASE_API_KEY"),
  },

  redis: {
    url: env("REDIS_URL", "redis://127.0.0.1:6379"),
  },

  telegram: {
    botToken: env("TELEGRAM_BOT_TOKEN"),
    chatId: env("TELEGRAM_CHAT_ID"),
    adminIds: env("TELEGRAM_ADMIN_IDS", "8288664961")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean),
    webhookSecret: env("TELEGRAM_WEBHOOK_SECRET"),
  },

  admin: {
    telegramId: env("ADMIN_TELEGRAM_ID", "8288664961"),
    name: env("ADMIN_NAME", "Administrador NOVACORE"),
  },

  limits: {
    maxTokensPerRequest: envInt("MAX_TOKENS_PER_REQUEST", 4096),
    maxHistoryMessages: envInt("MAX_HISTORY_MESSAGES", 20),
    maxAgentHops: envInt("MAX_AGENT_HOPS", 5),
    taskTimeoutMs: envInt("TASK_TIMEOUT_MS", 120000),
    rateLimitPerMin: envInt("RATE_LIMIT_PER_MIN", 60),
  },
};

/** Carrega o system prompt de um agente a partir de prompts/<agent>.system.md */
export function loadSystemPrompt(agentName) {
  const file = path.join(root, "prompts", `${agentName}.system.md`);
  if (!fs.existsSync(file)) {
    throw new Error(`Prompt não encontrado: ${file}`);
  }
  return fs.readFileSync(file, "utf8");
}

/** Carrega a knowledge base core */
export function loadKnowledgeBase() {
  const file = path.join(root, "knowledge-base", "novacore-core.json");
  if (!fs.existsSync(file)) return null;
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

export const AGENTS = ["nexus", "aura", "sentinel", "forge", "oracle"];
