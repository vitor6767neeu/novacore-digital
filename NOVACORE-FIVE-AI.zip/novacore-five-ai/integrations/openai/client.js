/**
 * Cliente oficial OpenAI para as cinco IAs do NOVACORE.
 * Usa o SDK "openai" e a Chat Completions API (compatível com Responses).
 */
import OpenAI from "openai";
import { config } from "../../memory/config.js";
import { logger } from "../../memory/logger.js";

const log = logger("openai");

let _client = null;

export function getOpenAI() {
  if (_client) return _client;
  if (!config.openai.apiKey) {
    throw new Error("OPENAI_API_KEY não configurada. Defina nos Secrets do servidor.");
  }
  const opts = { apiKey: config.openai.apiKey };
  if (config.openai.baseUrl) {
    opts.baseURL = config.openai.baseUrl;
  }
  _client = new OpenAI(opts);
  return _client;
}

/**
 * Chamada principal de chat com histórico e system prompt.
 * @param {object} opts
 * @param {string} opts.system - instrução de sistema
 * @param {Array<{role:string,content:string}>} opts.messages - histórico (user/assistant)
 * @param {string} [opts.model]
 * @param {number} [opts.temperature]
 * @param {number} [opts.maxTokens]
 * @param {string} [opts.agent] - nome do agente (para log)
 */
export async function chat({
  system,
  messages = [],
  model,
  temperature = 0.4,
  maxTokens,
  agent = "unknown",
}) {
  const client = getOpenAI();
  const usedModel = model || config.openai.model;
  const max_tokens = maxTokens || config.limits.maxTokensPerRequest;

  const payload = {
    model: usedModel,
    messages: [
      { role: "system", content: system },
      ...messages.filter((m) => m.role === "user" || m.role === "assistant"),
    ],
    temperature,
    max_tokens,
  };

  const start = Date.now();
  try {
    const completion = await client.chat.completions.create(payload);
    const choice = completion.choices?.[0];
    const text = choice?.message?.content ?? "";
    const usage = completion.usage || {};
    const latency = Date.now() - start;

    log.info(
      {
        agent,
        model: usedModel,
        tokens: usage.total_tokens,
        prompt_tokens: usage.prompt_tokens,
        completion_tokens: usage.completion_tokens,
        latencyMs: latency,
      },
      "openai.chat.ok"
    );

    return {
      text,
      model: usedModel,
      usage: {
        prompt_tokens: usage.prompt_tokens ?? 0,
        completion_tokens: usage.completion_tokens ?? 0,
        total_tokens: usage.total_tokens ?? 0,
      },
      finish_reason: choice?.finish_reason ?? null,
      configured: true,
      latencyMs: latency,
    };
  } catch (err) {
    const status = err?.status || err?.response?.status;
    log.error(
      { agent, model: usedModel, status, message: err.message },
      "openai.chat.error"
    );

    // Tratamento de limites e erros comuns
    if (status === 429) {
      throw new Error("Limite de requisições OpenAI atingido (429). Tente novamente em instantes.");
    }
    if (status === 401) {
      throw new Error("OPENAI_API_KEY inválida ou sem permissão.");
    }
    if (status === 400) {
      throw new Error(`Requisição inválida para OpenAI: ${err.message}`);
    }
    throw new Error(`Falha OpenAI: ${err.message}`);
  }
}

/**
 * Verifica se a chave e o modelo estão acessíveis.
 */
export async function healthCheck() {
  try {
    const r = await chat({
      system: "Responda apenas com a palavra OK.",
      messages: [{ role: "user", content: "ping" }],
      maxTokens: 5,
      temperature: 0,
      agent: "health",
    });
    return { ok: true, model: r.model, text: r.text.trim() };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}
