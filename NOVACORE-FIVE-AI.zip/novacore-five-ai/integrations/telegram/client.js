/**
 * Integração Telegram oficial do NOVACORE (BOT-FF-24H / @Ff24hbot).
 */
import { config } from "../../memory/config.js";
import { logger } from "../../memory/logger.js";

const log = logger("telegram");

export async function sendMessage(text, chatId = null) {
  if (!config.telegram.botToken) {
    return { ok: false, error: "TELEGRAM_BOT_TOKEN não configurado" };
  }
  const chat = chatId || config.telegram.chatId;
  if (!chat) {
    return { ok: false, error: "chatId não informado e TELEGRAM_CHAT_ID vazio" };
  }
  try {
    const r = await fetch(
      `https://api.telegram.org/bot${config.telegram.botToken}/sendMessage`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          chat_id: chat,
          text: String(text).slice(0, 4000),
          parse_mode: "HTML",
          disable_web_page_preview: true,
        }),
        signal: AbortSignal.timeout(15000),
      }
    );
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.ok) {
      log.warn({ status: r.status, body: j }, "telegram.send.fail");
      return { ok: false, error: j.description || `HTTP ${r.status}` };
    }
    return { ok: true, messageId: j.result?.message_id };
  } catch (e) {
    log.error({ err: e.message }, "telegram.send.error");
    return { ok: false, error: e.message };
  }
}

export async function notifyAdmin(text) {
  const adminId = config.admin.telegramId || config.telegram.adminIds[0];
  if (!adminId) return { ok: false, error: "admin id não configurado" };
  return sendMessage(`🛡 <b>NOVACORE</b>\n${text}`, adminId);
}

export function isAdmin(telegramUserId) {
  const id = String(telegramUserId);
  return (
    config.telegram.adminIds.includes(id) ||
    id === String(config.admin.telegramId)
  );
}

export async function healthCheck() {
  if (!config.telegram.botToken) {
    return { ok: false, error: "token não configurado" };
  }
  try {
    const r = await fetch(
      `https://api.telegram.org/bot${config.telegram.botToken}/getMe`,
      { signal: AbortSignal.timeout(10000) }
    );
    const j = await r.json();
    if (!j.ok) return { ok: false, error: j.description };
    return {
      ok: true,
      username: j.result?.username,
      id: j.result?.id,
      name: j.result?.first_name,
    };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}
