/**
 * Firebase Realtime Database oficial do NOVACORE (auto-bot-701e3).
 * Memória persistente separada por agente e por usuário.
 */
import admin from "firebase-admin";
import fs from "node:fs";
import { config } from "../../memory/config.js";
import { logger } from "../../memory/logger.js";

const log = logger("firebase");
let _db = null;
let _initialized = false;

export function initFirebase() {
  if (_initialized) return getDb();
  try {
    if (!admin.apps.length) {
      let credential = null;

      if (config.firebase.serviceAccountJson) {
        try {
          credential = admin.credential.cert(
            JSON.parse(config.firebase.serviceAccountJson)
          );
        } catch (e) {
          throw new Error(
            "FIREBASE_SERVICE_ACCOUNT_JSON inválido: " + e.message
          );
        }
      } else if (config.firebase.serviceAccountPath) {
        const json = JSON.parse(
          fs.readFileSync(config.firebase.serviceAccountPath, "utf8")
        );
        credential = admin.credential.cert(json);
      } else {
        try {
          credential = admin.credential.applicationDefault();
        } catch {
          log.warn(
            "Firebase sem service account. Memória persistente desabilitada até configurar FIREBASE_SERVICE_ACCOUNT_JSON ou PATH."
          );
          credential = null;
        }
      }

      if (!credential) {
        _initialized = true;
        return null;
      }

      admin.initializeApp({
        credential,
        databaseURL: config.firebase.databaseURL,
        storageBucket: config.firebase.storageBucket,
        projectId: config.firebase.projectId,
      });
    }
    _db = admin.database();
    _initialized = true;
    log.info({ projectId: config.firebase.projectId }, "firebase.ok");
    return _db;
  } catch (e) {
    log.error({ err: e.message }, "firebase.init.error");
    _initialized = true;
    return null;
  }
}

export function getDb() {
  if (!_initialized) return initFirebase();
  return _db;
}

/** Caminhos de memória por agente/usuário */
export function memoryPath(agent, userId = "global") {
  return `novacore/agents/${agent}/memory/${userId}`;
}

export function historyPath(agent, userId = "global") {
  return `novacore/agents/${agent}/history/${userId}`;
}

export function tasksPath(agent) {
  return `novacore/agents/${agent}/tasks`;
}

/**
 * Salva entrada de memória de longo prazo.
 */
export async function saveMemory(agent, userId, key, value) {
  const db = getDb();
  if (!db) return { ok: false, reason: "firebase_not_configured" };
  const ref = db.ref(`${memoryPath(agent, userId)}/${key}`);
  await ref.set({
    value,
    updatedAt: Date.now(),
    agent,
    userId,
  });
  return { ok: true };
}

/**
 * Lê memória de longo prazo.
 */
export async function loadMemory(agent, userId, key) {
  const db = getDb();
  if (!db) return null;
  const snap = await db.ref(`${memoryPath(agent, userId)}/${key}`).once("value");
  return snap.val();
}

/**
 * Lista chaves de memória do agente/usuário.
 */
export async function listMemoryKeys(agent, userId) {
  const db = getDb();
  if (!db) return [];
  const snap = await db.ref(memoryPath(agent, userId)).once("value");
  const val = snap.val() || {};
  return Object.keys(val);
}

/**
 * Adiciona mensagem ao histórico de conversa (circular, limitado).
 */
export async function appendHistory(agent, userId, role, content, meta = {}) {
  const db = getDb();
  if (!db) return { ok: false };
  const ref = db.ref(historyPath(agent, userId));
  const entry = {
    role,
    content: String(content).slice(0, 8000),
    ts: Date.now(),
    meta,
  };
  await ref.push(entry);
  // Limita tamanho (mantém as últimas N)
  const snap = await ref.orderByChild("ts").once("value");
  const items = [];
  snap.forEach((child) => {
    items.push({ key: child.key, ...child.val() });
  });
  const max = 100;
  if (items.length > max) {
    const toRemove = items.slice(0, items.length - max);
    for (const it of toRemove) {
      await ref.child(it.key).remove();
    }
  }
  return { ok: true };
}

/**
 * Recupera as últimas N mensagens do histórico.
 */
export async function getHistory(agent, userId, limit = 20) {
  const db = getDb();
  if (!db) return [];
  const snap = await db
    .ref(historyPath(agent, userId))
    .orderByChild("ts")
    .limitToLast(limit)
    .once("value");
  const list = [];
  snap.forEach((child) => {
    list.push(child.val());
  });
  return list;
}

/**
 * Registra tarefa concluída.
 */
export async function recordTask(agent, task) {
  const db = getDb();
  if (!db) return { ok: false };
  const ref = db.ref(tasksPath(agent)).push();
  await ref.set({
    ...task,
    agent,
    recordedAt: Date.now(),
  });
  return { ok: true, id: ref.key };
}

/**
 * Health check simples.
 */
export async function healthCheck() {
  try {
    const db = getDb();
    if (!db) return { ok: false, error: "não inicializado / sem credencial" };
    const ref = db.ref("novacore/_health");
    await ref.set({ ts: Date.now(), ok: true });
    const snap = await ref.once("value");
    return { ok: true, data: snap.val() };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}
