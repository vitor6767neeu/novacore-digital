/**
 * Inicia os cinco agentes em processos filhos (desenvolvimento local).
 * Em produção use PM2 ou o microservidor original.
 */
import { spawn } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");
const agents = ["nexus", "aura", "sentinel", "forge", "oracle"];

const children = [];

for (const name of agents) {
  const child = spawn(
    process.execPath,
    [path.join(root, "agents", name, "index.js")],
    {
      cwd: root,
      stdio: "inherit",
      env: process.env,
    }
  );
  children.push(child);
  console.log(`Iniciado: ${name} (pid ${child.pid})`);
}

function shutdown() {
  console.log("Encerrando agentes...");
  for (const c of children) {
    try {
      c.kill("SIGTERM");
    } catch {}
  }
  setTimeout(() => process.exit(0), 1500);
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
