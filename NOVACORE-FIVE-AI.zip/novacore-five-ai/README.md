# NOVACORE FIVE AI

Pacote independente com as **cinco inteligências artificiais reais** do NOVACORE DIGITAL:

| Agente    | Função                          |
|-----------|---------------------------------|
| **NEXUS** | Inteligência Central / Coordenação |
| **AURA**  | Comunicação e atendimento       |
| **SENTINEL** | Segurança e monitoramento    |
| **FORGE** | Infraestrutura e manutenção     |
| **ORACLE** | Pesquisa e conhecimento       |

## Características

- **Provedor oficial OpenAI** (SDK `openai`, Chat Completions)
- System prompts especializados + knowledge base versionada do NOVACORE
- Memória de curto prazo (histórico) e persistente no **Firebase Realtime Database** (projeto `auto-bot-701e3`)
- Comunicação real entre agentes via **Redis + BullMQ** (anti-loop com limite de hops)
- Integração **Telegram** (BOT-FF-24H / @Ff24hbot) — alertas e notificações
- Separação clara: dados confirmados × pendências × planos futuros × desconhecido
- Autonomia controlada (sem acesso a segredos, sem shell arbitrário)

## Requisitos

- Node.js 20+
- Redis 7+
- Conta OpenAI com chave API
- Service Account do Firebase (projeto auto-bot-701e3) — opcional para memória persistente
- Token do bot Telegram — opcional para alertas

## Instalação

```bash
cd novacore-five-ai
cp .env.example .env
# Edite .env e preencha OPENAI_API_KEY, REDIS_URL, etc.
npm install
```

### Variáveis obrigatórias para IA real

```
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini
```

### Firebase (memória persistente)

```
FIREBASE_PROJECT_ID=auto-bot-701e3
FIREBASE_DATABASE_URL=https://auto-bot-701e3-default-rtdb.firebaseio.com
FIREBASE_SERVICE_ACCOUNT_JSON={"type":"service_account",...}
```

Ou use `FIREBASE_SERVICE_ACCOUNT_PATH=/caminho/para/serviceAccount.json`.

### Telegram

```
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
TELEGRAM_ADMIN_IDS=8288664961
```

## Executar

```bash
# Um agente
npm run nexus
npm run aura
# ...

# Todos (desenvolvimento)
npm run start:all
```

Em produção, prefira PM2 ou integre aos processos do microservidor original (`novacore-microserver`).

## Testes

```bash
npm run test:openai      # exige OPENAI_API_KEY
npm run test:firebase    # exige service account
npm run test:agents      # identidades + knowledge base
```

Se a credencial não estiver disponível, o teste documenta a etapa como **PENDENTE** e não simula sucesso.

## Estrutura

```
novacore-five-ai/
├── agents/
│   ├── base-agent.js      # classe base compartilhada
│   ├── nexus/
│   ├── aura/
│   ├── sentinel/
│   ├── forge/
│   └── oracle/
├── prompts/               # system prompts oficiais
├── knowledge-base/        # novacore-core.json (versionado)
├── memory/                # config + logger
├── communication/         # Redis/BullMQ bus
├── integrations/
│   ├── openai/
│   ├── firebase/
│   └── telegram/
├── tests/
├── scripts/
├── .env.example
├── package.json
└── README.md
```

## Integração com o microservidor existente

Este pacote foi desenhado para conviver com o `novacore-microserver`:

- As filas usam o prefixo `nc.ai.*` (não colidem com `ms.*`).
- Você pode apontar os workers do microservidor para estes agentes ou rodar ambos em paralelo.
- O Gateway original continua responsável por autenticação HTTP e painel.

## Segurança (resumo)

- Nenhuma chave é embutida no código.
- Agentes não executam shell nem acessam secrets.
- Limite de hops entre agentes evita loops.
- Identidade e instruções centrais de um agente não podem ser alteradas por outro.
- Operações importantes são registradas (histórico + tasks no Firebase).

## Knowledge Base

Arquivo: `knowledge-base/novacore-core.json`

Campos:

- `confirmed` — dados fornecidos pelo proprietário
- `pending` — configurações que ainda precisam de Secrets
- `future_plans` — planos conhecidos
- `unknown` — o que explicitamente não foi informado

Atualize este arquivo e incremente `version` quando houver novas informações oficiais.

## Entrega

Este ZIP contém as cinco IAs implementadas em código, com:

- Integração real OpenAI
- Identidades e prompts distintos
- Knowledge base inicial do NOVACORE DIGITAL
- Memória Firebase (quando configurada)
- Comunicação inter-agentes
- Pronto para receber suas chaves oficiais nos Secrets
