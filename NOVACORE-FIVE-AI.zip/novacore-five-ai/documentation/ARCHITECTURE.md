# Arquitetura das Cinco IAs — NOVACORE DIGITAL

## Visão geral

```
Usuário / Telegram / Gateway
            │
            ▼
         NEXUS  (coordenação + roteamento inteligente)
         /  |  \  \
        /   |   \  \
     AURA  ORACLE FORGE SENTINEL
        \   |   /  /
         \  |  /  /
            ▼
     Redis (filas nc.ai.*) + Firebase (memória)
            │
            ▼
         OpenAI API (oficial)
```

## Fluxo típico

1. Solicitação chega ao NEXUS (via fila `nc.ai.nexus` ou chamada direta).
2. NEXUS interpreta a intenção (regras estáticas + decisão via modelo).
3. Se necessário, envia tarefa ao agente especializado (`sendToAgent`).
4. Agente especializado usa OpenAI com seu system prompt + knowledge base + histórico Firebase.
5. Resultado retorna; NEXUS pode consolidar ou entregar direto.
6. Histórico e tarefas são gravados no Firebase (separados por agente e userId).

## Anti-loop

Campo `meta.hops` incrementado a cada hop. Limite configurável (`MAX_AGENT_HOPS`, padrão 5).

## Memória

- **Curto prazo**: últimas N mensagens por agente/usuário (Firebase `history`).
- **Longo prazo**: chave/valor por agente/usuário (Firebase `memory`).
- **Tarefas**: log de execuções (Firebase `tasks`).

## Compatibilidade

Prefixo de filas: `nc.ai.*`  
Prefixo original do microservidor: `ms.*`  
Podem coexistir no mesmo Redis.
