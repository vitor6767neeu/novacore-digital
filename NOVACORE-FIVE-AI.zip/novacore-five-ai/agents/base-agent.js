/**
 * Classe base das cinco IAs do NOVACORE.
 * Cada agente especializa system prompt, roteamento e ferramentas.
 */
import { chat } from "../integrations/openai/client.js";
import {
  loadSystemPrompt,
  loadKnowledgeBase,
  config,
  AGENTS,
} from "../memory/config.js";
import {
  getHistory,
  appendHistory,
  saveMemory,
  loadMemory,
  recordTask,
} from "../integrations/firebase/client.js";
import {
  createWorker,
  sendToAgent,
  heartbeat,
  publishEvent,
} from "../communication/bus.js";
import { logger } from "../memory/logger.js";
import { notifyAdmin } from "../integrations/telegram/client.js";

export class BaseAgent {
  constructor(name) {
    if (!AGENTS.includes(name)) {
      throw new Error(`Agente inválido: ${name}`);
    }
    this.name = name;
    this.log = logger(name);
    this.systemPrompt = loadSystemPrompt(name);
    this.knowledge = loadKnowledgeBase();
    this.worker = null;
    this._running = false;
  }

  /** Enriquece o system prompt com trechos da knowledge base */
  buildSystem(extraContext = "") {
    const kbSummary = this.knowledge
      ? `
## Base de conhecimento NOVACORE (versão ${this.knowledge.version})
Projeto: ${this.knowledge.project.name}
Finalidade: ${this.knowledge.project.purpose}
Agentes: ${Object.keys(this.knowledge.confirmed.agents).join(", ")}
Telegram admin: ${this.knowledge.confirmed.telegram.admin_id}
Firebase: ${this.knowledge.confirmed.firebase.project_id}
Regras de segurança: ${this.knowledge.confirmed.security_rules.slice(0, 4).join("; ")}...
Pendências conhecidas: ${Object.keys(this.knowledge.pending).join(", ")}
`
      : "";
    return `${this.systemPrompt}\n${kbSummary}\n${extraContext}`.trim();
  }

  /**
   * Processa uma mensagem/tarefa do usuário ou de outro agente.
   */
  async process({
    userId = "global",
    message,
    type = "message",
    payload = {},
    meta = {},
    historyOverride = null,
  }) {
    const text =
      message ||
      payload.message ||
      payload.query ||
      payload.text ||
      JSON.stringify(payload);

    // Histórico curto prazo
    let history = historyOverride;
    if (!history) {
      try {
        const raw = await getHistory(this.name, userId, config.limits.maxHistoryMessages);
        history = raw.map((h) => ({
          role: h.role === "assistant" ? "assistant" : "user",
          content: h.content,
        }));
      } catch {
        history = [];
      }
    }

    const messages = [
      ...history,
      { role: "user", content: String(text).slice(0, 8000) },
    ];

    const system = this.buildSystem(
      meta.from
        ? `\n[Mensagem originada do agente: ${meta.from} | hops: ${meta.hops || 0}]`
        : ""
    );

    const result = await chat({
      system,
      messages,
      agent: this.name,
      temperature: this.name === "oracle" ? 0.3 : 0.4,
    });

    // Persiste histórico
    try {
      await appendHistory(this.name, userId, "user", text, { type, meta });
      await appendHistory(this.name, userId, "assistant", result.text, {
        model: result.model,
        usage: result.usage,
      });
    } catch (e) {
      this.log.warn({ err: e.message }, "history.persist.fail");
    }

    // Registra tarefa
    try {
      await recordTask(this.name, {
        type,
        userId,
        inputPreview: String(text).slice(0, 200),
        outputPreview: result.text.slice(0, 200),
        usage: result.usage,
        meta,
      });
    } catch {}

    return result;
  }

  /**
   * Solicita trabalho a outro agente (com anti-loop).
   */
  async delegate(targetAgent, type, payload, meta = {}) {
    if (targetAgent === this.name) {
      throw new Error("Agente não pode delegar para si mesmo");
    }
    return sendToAgent(targetAgent, type, payload, {
      ...meta,
      from: this.name,
      hops: (meta.hops || 0),
    });
  }

  /**
   * Handler padrão de fila — sobrescrito pelos agentes especializados se necessário.
   */
  async handleJob(job) {
    const { type, payload = {}, meta = {} } = job.data;
    const userId = payload.userId || meta.userId || "global";
    return this.process({
      userId,
      type,
      payload,
      meta,
      message: payload.message || payload.query || payload.text,
    });
  }

  /** Inicia o worker e o heartbeat */
  start() {
    if (this._running) return;
    this._running = true;
    this.worker = createWorker(this.name, (job) => this.handleJob(job));
    const beat = async () => {
      try {
        await heartbeat(this.name, { status: "running" });
      } catch (e) {
        this.log.warn(e.message);
      }
    };
    beat();
    this._hbInterval = setInterval(beat, 15000);
    this.log.info("agente iniciado");
    return this;
  }

  async stop() {
    if (this._hbInterval) clearInterval(this._hbInterval);
    if (this.worker) await this.worker.close();
    this._running = false;
    this.log.info("agente parado");
  }

  async remember(userId, key, value) {
    return saveMemory(this.name, userId, key, value);
  }

  async recall(userId, key) {
    return loadMemory(this.name, userId, key);
  }

  async alertAdmin(text) {
    return notifyAdmin(`[${this.name.toUpperCase()}] ${text}`);
  }
}
