/**
 * AURA — Inteligência de Comunicação
 */
import { BaseAgent } from "../base-agent.js";

class AuraAgent extends BaseAgent {
  constructor() {
    super("aura");
  }

  async handleJob(job) {
    const { type, payload = {}, meta = {} } = job.data;
    const userId = payload.userId || meta.userId || "global";
    const message = payload.message || payload.text || "";

    if (!message) {
      throw new Error("AURA: payload.message vazio");
    }

    const result = await this.process({
      userId,
      message,
      type: type || "atendimento",
      payload,
      meta,
    });

    return {
      agent: "aura",
      text: result.text,
      model: result.model,
      usage: result.usage,
      configured: result.configured,
    };
  }
}

const agent = new AuraAgent();
agent.start();

process.on("SIGTERM", () => agent.stop().then(() => process.exit(0)));
process.on("SIGINT", () => agent.stop().then(() => process.exit(0)));

export default agent;
