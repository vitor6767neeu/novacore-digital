/**
 * FORGE — Inteligência de Infraestrutura
 */
import { BaseAgent } from "../base-agent.js";
import fs from "node:fs";
import path from "node:path";
import { config } from "../../memory/config.js";

class ForgeAgent extends BaseAgent {
  constructor() {
    super("forge");
  }

  /** Lê arquivos de configuração permitidos (somente leitura, whitelist) */
  safeReadConfig() {
    const allowed = [
      "package.json",
      ".env.example",
      "knowledge-base/novacore-core.json",
    ];
    const out = {};
    for (const rel of allowed) {
      const full = path.join(config.root, rel);
      try {
        if (fs.existsSync(full)) {
          out[rel] = fs.readFileSync(full, "utf8").slice(0, 8000);
        }
      } catch {}
    }
    return out;
  }

  async handleJob(job) {
    const { type, payload = {}, meta = {} } = job.data;
    const userId = payload.userId || meta.userId || "global";
    const message =
      payload.message || payload.query || payload.text || type || "";

    let extra = "";
    if (
      type === "backup" ||
      type === "manutencao" ||
      type === "infraestrutura" ||
      /config|package|dependenc|docker|arquivo/i.test(message)
    ) {
      const files = this.safeReadConfig();
      extra = `\n\n[ARQUIVOS DE CONFIGURAÇÃO DISPONÍVEIS - somente leitura]\n${JSON.stringify(files, null, 2)}`;
    }

    const result = await this.process({
      userId,
      message: String(message) + extra,
      type: type || "tecnico",
      payload,
      meta,
    });

    return {
      agent: "forge",
      text: result.text,
      model: result.model,
      usage: result.usage,
    };
  }
}

const agent = new ForgeAgent();
agent.start();

process.on("SIGTERM", () => agent.stop().then(() => process.exit(0)));
process.on("SIGINT", () => agent.stop().then(() => process.exit(0)));

export default agent;
