/**
 * ORACLE — Inteligência de Pesquisa
 */
import { BaseAgent } from "../base-agent.js";
import { loadKnowledgeBase } from "../../memory/config.js";

class OracleAgent extends BaseAgent {
  constructor() {
    super("oracle");
  }

  async handleJob(job) {
    const { type, payload = {}, meta = {} } = job.data;
    const userId = payload.userId || meta.userId || "global";
    const query =
      payload.query || payload.message || payload.text || "";

    if (!query) {
      throw new Error("ORACLE: payload.query ou message vazio");
    }

    // Injeta knowledge base completa no contexto da pergunta
    const kb = loadKnowledgeBase();
    const kbContext = kb
      ? `\n\n[KNOWLEDGE BASE COMPLETA - use apenas o que estiver aqui ou declare desconhecido]\n${JSON.stringify(kb, null, 2)}`
      : "";

    const result = await this.process({
      userId,
      message: query + kbContext,
      type: type || "pesquisa",
      payload,
      meta,
    });

    return {
      agent: "oracle",
      text: result.text,
      model: result.model,
      usage: result.usage,
      knowledgeVersion: kb?.version || null,
    };
  }
}

const agent = new OracleAgent();
agent.start();

process.on("SIGTERM", () => agent.stop().then(() => process.exit(0)));
process.on("SIGINT", () => agent.stop().then(() => process.exit(0)));

export default agent;
