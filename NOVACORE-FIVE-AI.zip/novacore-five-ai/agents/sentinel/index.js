/**
 * SENTINEL — Inteligência de Segurança e Monitoramento
 */
import { BaseAgent } from "../base-agent.js";
import { redis, publishEvent } from "../../communication/bus.js";
import { AGENTS } from "../../memory/config.js";
import { notifyAdmin } from "../../integrations/telegram/client.js";

class SentinelAgent extends BaseAgent {
  constructor() {
    super("sentinel");
    this.lastState = {};
  }

  async collectStatus() {
    const r = redis();
    const statuses = [];
    for (const name of AGENTS) {
      const raw = await r.get(`nc.ai.hb.${name}`);
      if (!raw) {
        statuses.push({ name, status: "stopped" });
      } else {
        try {
          const hb = JSON.parse(raw);
          const age = Date.now() - hb.ts;
          statuses.push({
            name,
            status: age > 45000 ? "unresponsive" : "running",
            ageMs: age,
            pid: hb.pid,
          });
        } catch {
          statuses.push({ name, status: "unknown" });
        }
      }
    }
    return statuses;
  }

  async handleJob(job) {
    const { type, payload = {}, meta = {} } = job.data;
    const userId = payload.userId || meta.userId || "global";
    const message =
      payload.message || payload.query || payload.text || type || "";

    // Sempre anexa status atual ao contexto
    const statuses = await this.collectStatus();
    const statusText = statuses
      .map((s) => `- ${s.name}: ${s.status}${s.ageMs ? ` (${s.ageMs}ms)` : ""}`)
      .join("\n");

    const enriched = `${message}\n\n[STATUS ATUAL DOS AGENTES]\n${statusText}`;

    const result = await this.process({
      userId,
      message: enriched,
      type: type || "monitoramento",
      payload,
      meta,
    });

    // Se detectar problema crítico na resposta, notifica admin
    if (
      /crítico|critical|parado|unresponsive|falha grave/i.test(result.text)
    ) {
      await notifyAdmin(result.text.slice(0, 1500)).catch(() => {});
    }

    return {
      agent: "sentinel",
      text: result.text,
      model: result.model,
      usage: result.usage,
      statuses,
    };
  }

  /** Loop de monitoramento periódico (além do worker) */
  startMonitor(intervalMs = 30000) {
    const tick = async () => {
      try {
        const statuses = await this.collectStatus();
        for (const s of statuses) {
          const prev = this.lastState[s.name];
          if (prev && prev !== "running" && s.status === "running") {
            await notifyAdmin(`✅ Agente ${s.name} voltou a funcionar.`);
          }
          if (prev === "running" && s.status !== "running") {
            await notifyAdmin(
              `⚠️ Agente ${s.name} está ${s.status}.`
            );
          }
          this.lastState[s.name] = s.status;
        }
        await publishEvent("status", { agents: statuses });
      } catch (e) {
        this.log.warn(e.message);
      }
    };
    tick();
    this._monitorInterval = setInterval(tick, intervalMs);
  }
}

const agent = new SentinelAgent();
agent.start();
agent.startMonitor(30000);

process.on("SIGTERM", () => agent.stop().then(() => process.exit(0)));
process.on("SIGINT", () => agent.stop().then(() => process.exit(0)));

export default agent;
