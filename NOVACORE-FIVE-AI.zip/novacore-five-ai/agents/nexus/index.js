/**
 * NEXUS — Inteligência Central
 * Coordena os demais agentes, interpreta pedidos e entrega respostas finais.
 */
import { BaseAgent } from "../base-agent.js";
import { sendToAgent, queue } from "../../communication/bus.js";
import { config } from "../../memory/config.js";

const ROUTES = {
  atendimento: "aura",
  mensagem: "aura",
  suporte: "aura",
  conversa: "aura",
  pesquisa: "oracle",
  analise: "oracle",
  relatorio: "oracle",
  conhecimento: "oracle",
  backup: "forge",
  manutencao: "forge",
  infraestrutura: "forge",
  tecnico: "forge",
  seguranca: "sentinel",
  alerta: "sentinel",
  monitoramento: "sentinel",
  logs: "sentinel",
};

class NexusAgent extends BaseAgent {
  constructor() {
    super("nexus");
  }

  /**
   * Interpreta a intenção e decide se responde ou roteia.
   */
  async handleJob(job) {
    const { type, payload = {}, meta = {} } = job.data;
    const userId = payload.userId || meta.userId || "global";
    const message =
      payload.message || payload.query || payload.text || type || "";

    // Se já veio com agente forçado
    if (payload.agent && payload.agent !== "nexus") {
      const childId = await this.delegate(
        payload.agent,
        type || "task",
        payload,
        meta
      );
      return {
        routedTo: payload.agent,
        childJobId: childId,
        note: "Roteado por solicitação explícita",
      };
    }

    // Roteamento por tipo conhecido
    const target = ROUTES[type];
    if (target) {
      const childId = await this.delegate(target, type, payload, meta);
      return {
        routedTo: target,
        childJobId: childId,
        note: `Tipo "${type}" roteado para ${target}`,
      };
    }

    // Interpretação via OpenAI (NEXUS decide)
    const decisionPrompt = `
O usuário enviou a seguinte solicitação:

"""
${String(message).slice(0, 3000)}
"""

Com base nas suas responsabilidades, responda em JSON puro (sem markdown) com uma das opções:

1. Responder você mesmo:
{"action":"answer","reason":"..."}

2. Rotear para outro agente:
{"action":"route","target":"aura|oracle|forge|sentinel","reason":"...","rewritten":"mensagem clara para o agente"}

Escolha apenas uma ação.
`;

    const decision = await this.process({
      userId,
      message: decisionPrompt,
      type: "decide",
      meta: { ...meta, internal: true },
      historyOverride: [], // decisão sem histórico de usuário
    });

    let parsed;
    try {
      const raw = decision.text.trim();
      const jsonMatch = raw.match(/\{[\s\S]*\}/);
      parsed = JSON.parse(jsonMatch ? jsonMatch[0] : raw);
    } catch {
      // Se não parseou, responde direto
      return {
        action: "answer",
        text: decision.text,
        model: decision.model,
        usage: decision.usage,
      };
    }

    if (parsed.action === "route" && parsed.target && parsed.target !== "nexus") {
      const childPayload = {
        ...payload,
        message: parsed.rewritten || message,
        userId,
      };
      const childId = await this.delegate(
        parsed.target,
        type || "task",
        childPayload,
        { ...meta, reason: parsed.reason }
      );
      return {
        action: "route",
        routedTo: parsed.target,
        childJobId: childId,
        reason: parsed.reason,
      };
    }

    // Resposta direta do NEXUS
    const answer = await this.process({
      userId,
      message,
      type: type || "message",
      payload,
      meta,
    });
    return {
      action: "answer",
      text: answer.text,
      model: answer.model,
      usage: answer.usage,
      reason: parsed.reason,
    };
  }
}

const agent = new NexusAgent();
agent.start();

// Graceful shutdown
process.on("SIGTERM", () => agent.stop().then(() => process.exit(0)));
process.on("SIGINT", () => agent.stop().then(() => process.exit(0)));

export default agent;
