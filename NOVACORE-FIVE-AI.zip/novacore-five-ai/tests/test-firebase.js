/**
 * Teste de leitura/escrita no Firebase Realtime Database oficial.
 */
import "dotenv/config";
import {
  initFirebase,
  healthCheck,
  saveMemory,
  loadMemory,
  appendHistory,
  getHistory,
} from "../integrations/firebase/client.js";

async function main() {
  console.log("=== Teste Firebase NOVACORE (auto-bot-701e3) ===");
  initFirebase();
  const h = await healthCheck();
  console.log("Health:", h);

  if (!h.ok) {
    console.error(
      "PENDENTE: Firebase não configurado. Defina FIREBASE_SERVICE_ACCOUNT_JSON ou FIREBASE_SERVICE_ACCOUNT_PATH nos Secrets."
    );
    process.exit(2);
  }

  const agent = "nexus";
  const userId = "test-user";
  await saveMemory(agent, userId, "teste", { ok: true, ts: Date.now() });
  const mem = await loadMemory(agent, userId, "teste");
  console.log("Memory roundtrip:", mem);

  await appendHistory(agent, userId, "user", "mensagem de teste");
  await appendHistory(agent, userId, "assistant", "resposta de teste");
  const hist = await getHistory(agent, userId, 5);
  console.log("History length:", hist.length);

  console.log("✅ Teste Firebase concluído.");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
