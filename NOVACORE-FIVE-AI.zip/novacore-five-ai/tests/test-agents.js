/**
 * Teste unitário das identidades e knowledge base (sem fila).
 * Usa OpenAI se a chave estiver presente.
 */
import "dotenv/config";
import { BaseAgent } from "../agents/base-agent.js";
import { loadKnowledgeBase } from "../memory/config.js";

async function main() {
  console.log("=== Teste de identidades e knowledge base ===");
  const kb = loadKnowledgeBase();
  if (!kb) {
    console.error("Knowledge base não encontrada");
    process.exit(1);
  }
  console.log("KB version:", kb.version);
  console.log("Projeto:", kb.project.name);
  console.log("Agentes confirmados:", Object.keys(kb.confirmed.agents));
  console.log("Telegram admin:", kb.confirmed.telegram.admin_id);
  console.log("Firebase project:", kb.confirmed.firebase.project_id);

  if (!process.env.OPENAI_API_KEY) {
    console.log(
      "\nPENDENTE: OPENAI_API_KEY ausente — identidades não serão validadas via modelo."
    );
    console.log("A knowledge base e os prompts estão carregados corretamente.");
    process.exit(0);
  }

  for (const name of ["nexus", "aura", "sentinel", "forge", "oracle"]) {
    const agent = new BaseAgent(name);
    const r = await agent.process({
      userId: "test",
      message:
        "Em no máximo duas frases: diga seu nome, sua função e uma regra de segurança do NOVACORE que você respeita.",
      historyOverride: [],
    });
    console.log(`\n--- ${name.toUpperCase()} ---`);
    console.log(r.text);
  }

  console.log("\n✅ Teste de agentes concluído.");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
