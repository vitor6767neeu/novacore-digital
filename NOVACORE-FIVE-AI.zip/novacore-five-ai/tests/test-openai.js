/**
 * Teste de conexão real com OpenAI.
 * Requer OPENAI_API_KEY no ambiente.
 */
import "dotenv/config";
import { healthCheck, chat } from "../integrations/openai/client.js";
import { loadSystemPrompt } from "../memory/config.js";

async function main() {
  console.log("=== Teste OpenAI Oficial ===");
  if (!process.env.OPENAI_API_KEY) {
    console.error("PENDENTE: OPENAI_API_KEY não definida. Configure nos Secrets.");
    process.exit(2);
  }

  const health = await healthCheck();
  console.log("Health:", health);
  if (!health.ok) {
    console.error("Falha no health check OpenAI");
    process.exit(1);
  }

  // Teste de identidade de cada agente (system prompt diferente)
  for (const agent of ["nexus", "aura", "sentinel", "forge", "oracle"]) {
    const system = loadSystemPrompt(agent);
    const r = await chat({
      system,
      messages: [
        {
          role: "user",
          content:
            "Responda em uma frase: quem é você e qual sua função no NOVACORE DIGITAL?",
        },
      ],
      maxTokens: 150,
      temperature: 0.3,
      agent,
    });
    console.log(`\n[${agent.toUpperCase()}]`);
    console.log(r.text);
    console.log(`tokens=${r.usage.total_tokens} model=${r.model}`);
  }

  console.log("\n✅ Teste OpenAI concluído com sucesso.");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
