/**
 * Verifica se o barramento e os agentes exportam a interface esperada.
 * Não exige Redis/OpenAI em execução para a verificação estrutural.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");

const required = [
  "agents/base-agent.js",
  "agents/nexus/index.js",
  "agents/aura/index.js",
  "agents/sentinel/index.js",
  "agents/forge/index.js",
  "agents/oracle/index.js",
  "communication/bus.js",
  "integrations/openai/client.js",
  "integrations/firebase/client.js",
  "integrations/telegram/client.js",
  "prompts/nexus.system.md",
  "prompts/aura.system.md",
  "prompts/sentinel.system.md",
  "prompts/forge.system.md",
  "prompts/oracle.system.md",
  "knowledge-base/novacore-core.json",
];

let ok = true;
for (const rel of required) {
  const full = path.join(root, rel);
  if (!fs.existsSync(full)) {
    console.error("FALTANDO:", rel);
    ok = false;
  } else {
    console.log("OK:", rel);
  }
}

const kb = JSON.parse(
  fs.readFileSync(path.join(root, "knowledge-base/novacore-core.json"), "utf8")
);
console.log("\nKnowledge base version:", kb.version);
console.log("Admin Telegram:", kb.confirmed.telegram.admin_id);
console.log("Firebase project:", kb.confirmed.firebase.project_id);

if (!ok) process.exit(1);
console.log("\n✅ Estrutura de comunicação e agentes verificada.");
