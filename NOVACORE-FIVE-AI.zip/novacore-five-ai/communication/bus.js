/**
 * Barramento de comunicação entre as cinco IAs.
 * Usa Redis + BullMQ (compatível com o microservidor original).
 */
import IORedis from "ioredis";
import { Queue, Worker } from "bullmq";
import { config } from "../memory/config.js";
import { logger } from "../memory/logger.js";

const log = logger("comm");

let _redis = null;
const queues = {};

export function redis() {
  if (!_redis) {
    _redis = new IORedis(config.redis.url, {
      maxRetriesPerRequest: null,
      enableReadyCheck: true,
      retryStrategy: (times) => Math.min(times * 200, 2000),
    });
  }
  return _redis;
}

export function newRedis() {
  return new IORedis(config.redis.url, { maxRetriesPerRequest: null });
}

export function queue(name) {
  const key = `nc.ai.${name}`;
  if (!queues[key]) {
    queues[key] = new Queue(key, { connection: redis() });
  }
  return queues[key];
}

export const jobDefaults = {
  attempts: 3,
  backoff: { type: "exponential", delay: 2000 },
  removeOnComplete: 200,
  removeOnFail: 500,
};

/**
 * Envia tarefa para outro agente.
 * @returns job id
 */
export async function sendToAgent(targetAgent, type, payload, meta = {}) {
  const hops = (meta.hops || 0) + 1;
  if (hops > config.limits.maxAgentHops) {
    throw new Error(
      `Limite de hops entre agentes excedido (${config.limits.maxAgentHops}). Possível loop.`
    );
  }
  const q = queue(targetAgent);
  const job = await q.add(
    type,
    {
      type,
      payload,
      meta: { ...meta, hops, from: meta.from || "system", ts: Date.now() },
    },
    {
      ...jobDefaults,
      timeout: config.limits.taskTimeoutMs,
    }
  );
  log.info(
    { target: targetAgent, type, jobId: job.id, hops },
    "task.sent"
  );
  return job.id;
}

/**
 * Cria worker para um agente.
 */
export function createWorker(agentName, handler) {
  const qName = `nc.ai.${agentName}`;
  const w = new Worker(
    qName,
    async (job) => {
      const start = Date.now();
      try {
        const result = await handler(job);
        log.info(
          {
            agent: agentName,
            type: job.name,
            jobId: job.id,
            ms: Date.now() - start,
          },
          "task.done"
        );
        return result;
      } catch (err) {
        log.error(
          {
            agent: agentName,
            type: job.name,
            jobId: job.id,
            err: err.message,
          },
          "task.fail"
        );
        throw err;
      }
    },
    {
      connection: redis(),
      concurrency: 2,
    }
  );
  w.on("failed", (job, err) => {
    log.warn(
      { agent: agentName, jobId: job?.id, err: err.message },
      "worker.failed"
    );
  });
  return w;
}

/**
 * Publica evento de controle (ex: alerta, status).
 */
export async function publishEvent(channel, data) {
  await redis().publish(
    `nc.ai.events.${channel}`,
    JSON.stringify({ ...data, ts: Date.now() })
  );
}

/**
 * Heartbeat simples do agente.
 */
export async function heartbeat(agentName, extra = {}) {
  const key = `nc.ai.hb.${agentName}`;
  const payload = {
    agent: agentName,
    pid: process.pid,
    ts: Date.now(),
    ...extra,
  };
  await redis().set(key, JSON.stringify(payload), "EX", 60);
}
